def test_health_returns_ok(client):
    response = client.get("/health")

    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "ok"
    assert "timestamp" in data
    assert data["service"] == "conecta-resto-mvp"