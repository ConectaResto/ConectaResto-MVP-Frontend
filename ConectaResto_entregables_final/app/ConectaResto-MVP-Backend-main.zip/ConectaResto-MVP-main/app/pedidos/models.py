from decimal import Decimal

from app.extensions import db
from app.models.base import BaseModel


class Pedido(BaseModel):
    ESTADOS_NO_CANCELADOS = ("PENDIENTE", "EN_PREPARACION", "LISTO", "ENTREGADO")
    ESTADOS = (*ESTADOS_NO_CANCELADOS, "CANCELADO")

    __tablename__ = "pedidos"
    __table_args__ = (
        db.CheckConstraint(
            "estado IN ('PENDIENTE', 'EN_PREPARACION', 'LISTO', 'ENTREGADO', 'CANCELADO')",
            name="ck_pedidos_estado",
        ),
        db.CheckConstraint(
            "origen IN ('MESERO', 'PUBLICO')",
            name="ck_pedidos_origen",
        ),
        db.CheckConstraint(
            "estado_preparacion IN ('NO_ENVIADO', 'RECIBIDO', 'EN_COCINA', 'LISTO_PARA_SERVIR')",
            name="ck_pedidos_estado_preparacion",
        ),
    )

    servicio_id = db.Column(
        db.Integer, db.ForeignKey("servicios.id"), nullable=False
    )
    origen = db.Column(db.String(20), nullable=False)
    creado_por_id = db.Column(
        db.Integer, db.ForeignKey("usuarios.id"), nullable=True
    )
    autorizado_por_id = db.Column(
        db.Integer, db.ForeignKey("usuarios.id"), nullable=True
    )
    autorizado_at = db.Column(db.DateTime, nullable=True)
    estado = db.Column(db.String(20), nullable=False, default="PENDIENTE")
    estado_preparacion = db.Column(
        db.String(30), nullable=False, default="NO_ENVIADO"
    )

    servicio = db.relationship("Servicio", backref=db.backref("pedidos", lazy=True))
    creado_por = db.relationship(
        "Usuario", foreign_keys=[creado_por_id], backref=db.backref("pedidos_creados", lazy=True)
    )
    autorizado_por = db.relationship(
        "Usuario", foreign_keys=[autorizado_por_id], backref=db.backref("pedidos_autorizados", lazy=True)
    )

    def __repr__(self):
        return f"<Pedido {self.id}: servicio={self.servicio_id}, estado={self.estado}>"


class DetallePedido(BaseModel):
    __tablename__ = "detalles_pedido"

    pedido_id = db.Column(
        db.Integer, db.ForeignKey("pedidos.id"), nullable=False
    )
    producto_id = db.Column(
        db.Integer, db.ForeignKey("products.id"), nullable=False
    )
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_unitario = db.Column(db.Numeric(10, 2), nullable=False)

    pedido = db.relationship("Pedido", backref=db.backref("detalles", lazy=True))
    producto = db.relationship("Product", backref=db.backref("detalles_pedido", lazy=True))

    def __repr__(self):
        return f"<DetallePedido {self.id}: pedido={self.pedido_id}, producto={self.producto_id}, cantidad={self.cantidad}>"
